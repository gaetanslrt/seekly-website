use std::path::Path;
use std::process::{Command};
use std::error::Error;


pub fn open_file(path: &Path) -> Result<(), Box<dyn Error>> {

    let file_extension = path.extension().and_then(|e| e.to_str()).unwrap_or_default();
    if path.is_file() {
        if file_extension.is_empty() 
        {
            #[cfg(target_os = "linux")]
            Command::new("wine")
                .arg("notepad.exe") 
                .arg(path)
                .spawn()?;
        } 
        else 
        {
            match file_extension 
            {
                "txt" | "docx" | "pub" => 
                {
                    #[cfg(target_os = "linux")]
                    Command::new("wine")
                        .arg("notepad.exe")
                        .arg(path)
                        .spawn()?;
                }
                "jpg" | "png" | "jpeg" => 
                {
                    #[cfg(target_os = "linux")]
                    Command::new("eog")
                        .arg(path)
                        .spawn()?;
                }
                _ => 
                {

                    #[cfg(target_os = "linux")]
                    Command::new("wine")
                        .arg("explorer.exe")
                        .arg(path)
                        .spawn()?;
                }
            }
        }
    } else 
    {
        return Err("Le chemin n'est pas un fichier valide.".into());
    }

    Ok(())
}
