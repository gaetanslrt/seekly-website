use regex::Regex;

pub fn is_math_expression(query: &str) -> bool {
    let re = Regex::new(r"^[\d\+\-\*/\(\)\.\s]+$").unwrap();
    re.is_match(query.trim())
}

pub fn evaluate_expression(expr: &str) -> Result<f64, Box<dyn std::error::Error>> {
    let value = meval::eval_str(expr)?;
    Ok(value)
}
