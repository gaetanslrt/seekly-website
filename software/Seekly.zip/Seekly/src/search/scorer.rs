use std::path::PathBuf;
use crate::search::finder::SearchResult;

#[derive(Clone)]
pub struct ScoredResult {
    pub path: PathBuf,
    pub score: f64,
}

pub fn score_results(results: &[SearchResult], query: &str) -> Vec<ScoredResult> 
{
    let query_lc = query.to_lowercase();
    results.iter().map(|r| 
        {
        let file_name = r.path.file_name()
            .map(|s| s.to_string_lossy().to_lowercase())
            .unwrap_or_default();
        let score = if file_name.contains(&query_lc) && !file_name.is_empty() 
        {
            query_lc.len() as f64 / file_name.len() as f64
        } 
        else 
        {
            0.0
        };
        ScoredResult { path: r.path.clone(), score }
    }).collect()
}
