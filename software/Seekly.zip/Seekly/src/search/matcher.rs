use std::path::Path;

pub fn matches(path: &Path, query: &str) -> bool 
{
    if let Some(name) = path.file_name() 
    {
        let name_str = name.to_string_lossy().to_lowercase();
        let query = query.to_lowercase();
        name_str.contains(&query)
    } 
    else 
    {
        false
    }
}
