use std::path::{Path, PathBuf};
use walkdir::WalkDir;
use crate::search::matcher;

#[derive(Clone, Debug)]
pub struct SearchResult {
    pub path: PathBuf,
}

pub fn search_files(base_path: &str, query: &str, recursive: bool) -> Vec<SearchResult> 
{
    let mut results = Vec::new();
    let path = Path::new(base_path);
    if !recursive {
        if let Ok(entries) = std::fs::read_dir(path) 
        {
            for entry in entries.flatten() 
            {
                let path_buf = entry.path();
                if matcher::matches(&path_buf, query) 
                {
                    results.push(SearchResult { path: path_buf });
                }
            }
        }
    } 
    else 
    {
        for entry in WalkDir::new(path).into_iter().filter_map(|e| e.ok()) 
        {
            let path_buf = entry.path().to_path_buf();
            if matcher::matches(&path_buf, query) 
            {
                results.push(SearchResult { path: path_buf });
            }
        }
    }
    results
}
