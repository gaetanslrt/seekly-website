use seekly::ui::gui::run_gui;

fn main() -> Result<(), eframe::Error> {
    run_gui();
    Ok(())
}