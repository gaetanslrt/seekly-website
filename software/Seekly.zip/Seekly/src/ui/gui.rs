use eframe::egui::*;
use eframe::{App, Frame, CreationContext};
use std::collections::HashMap;
use std::path::Path;
use image::GenericImageView;
use crate::search::finder;
use crate::search::scorer;

pub fn run_gui() {
    let options = eframe::NativeOptions {
        follow_system_theme: false,
        default_theme: eframe::Theme::Light,
        ..Default::default()
    };
    let _ = eframe::run_native(
        "Seekly",
        options,
        Box::new(|cc| {
            cc.egui_ctx.set_fonts(custom_fonts());
            Box::new(SeeklyApp::new(cc))
        }),
    );
}

fn custom_fonts() -> FontDefinitions {
    let mut fonts = FontDefinitions::default();
    fonts.font_data.insert(
        "cartoon".to_string(),
        FontData::from_static(include_bytes!("../../assets/ComicNeue-Bold.ttf")),
    );
    fonts.families.entry(FontFamily::Name("cartoon".into()))
        .or_default()
        .insert(0, "cartoon".to_string());
    fonts
}

pub struct SeeklyApp {
    query: String,
    results: Vec<(f32, String)>,
    icons: HashMap<String, TextureHandle>,
}

impl SeeklyApp {
    pub fn new(cc: &CreationContext<'_>) -> Self {
        let mut icons = HashMap::new();
        let icon_paths = vec![
            ("folder", "assets/icons/folder.png"),
            ("pdf", "assets/icons/file_pdf.png"),
            ("image", "assets/icons/file_image.png"),
            ("audio", "assets/icons/file_audio.png"),
            ("video", "assets/icons/file_video.png"),
            ("word", "assets/icons/file_word.png"),
            ("excel", "assets/icons/file_excel.png"),
            ("powerpoint", "assets/icons/file_powerpoint.png"),
            ("code", "assets/icons/file_code.png"),
            ("generic", "assets/icons/file_generic.png"),
        ];

        for (key, path) in icon_paths {
            if let Ok(texture) = load_texture(&cc.egui_ctx, path) {
                icons.insert(key.to_string(), texture);
            }
        }

        Self {
            query: String::new(),
            results: Vec::new(),
            icons,
        }
    }

    fn get_icon_for_file(&self, path: &str) -> Option<&TextureHandle> {
        let ext = Path::new(path)
            .extension()
            .and_then(|e| e.to_str())
            .unwrap_or("")
            .to_lowercase();

        match ext.as_str() {
            "pdf" => self.icons.get("pdf"),
            "png" | "jpg" | "jpeg" | "gif" => self.icons.get("image"),
            "mp3" | "wav" | "flac" => self.icons.get("audio"),
            "mp4" | "mkv" | "avi" | "mov" => self.icons.get("video"),
            "doc" | "docx" => self.icons.get("word"),
            "xls" | "xlsx" => self.icons.get("excel"),
            "ppt" | "pptx" => self.icons.get("powerpoint"),
            "rs" | "py" | "js" | "html" => self.icons.get("code"),
            _ => {
                if Path::new(path).is_dir() {
                    self.icons.get("folder")
                } else {
                    self.icons.get("generic")
                }
            }
        }
    }

    fn perform_search(&mut self) {
        if self.query.trim().is_empty() {
            self.results.clear();
            return;
        }

        let raw_results = finder::search_files(".", &self.query, true);
        let scored = scorer::score_results(&raw_results, &self.query);
        self.results = scored
            .into_iter()
            .take(10)
            .map(|s| (s.score as f32, s.path.to_string_lossy().into_owned()))
            .collect();
    }
}

impl App for SeeklyApp {
    fn update(&mut self, ctx: &Context, _frame: &mut Frame) {
        CentralPanel::default().show(ctx, |ui| {
            ui.vertical_centered(|ui| {
                ui.add_space(20.0);
                ui.label(
                    RichText::new("Seekly")
                        .font(FontId::new(48.0, FontFamily::Name("cartoon".into())))
                        .color(Color32::BLACK),
                );

                ui.add_space(30.0);

                ui.horizontal(|ui| {
                    let search_edit = TextEdit::singleline(&mut self.query)
                        .hint_text("Search files...")
                        .font(FontId::new(24.0, FontFamily::Name("cartoon".into())))
                        .desired_width(400.0)
                        .margin(vec2(12.0, 10.0))
                        .frame(true);

                    let response = ui.add_sized(vec2(400.0, 40.0), search_edit);

                    if response.changed() {
                        self.perform_search();
                    }

                    if ui.add_sized(vec2(40.0, 40.0), Button::new("🔍")).clicked() {
                        self.perform_search();
                    }
                });

                ui.add_space(30.0);

                ScrollArea::vertical().max_height(400.0).show(ui, |ui| {
                    for (_score, path) in &self.results {
                        ui.add_space(10.0);
                        ui.horizontal(|ui| {
                            if let Some(icon) = self.get_icon_for_file(path) 
                            {
                                ui.add(egui::Image::new(icon).fit_to_exact_size(vec2(24.0, 24.0)));
                            }
                            let file_name = path.split('/').last().unwrap_or("unknown");
                            let display = format!("{} - {}", file_name, path);
                            ui.label(
                                RichText::new(display)
                                    .font(FontId::new(22.0, FontFamily::Name("cartoon".into())))
                                    .strong(),
                            );
                        });
                    }
                });
            });
        });
    }
}

fn load_texture(ctx: &Context, path: &str) -> Result<TextureHandle, image::ImageError> {
    let image = image::open(path)?;
    let size = [image.width() as usize, image.height() as usize];
    let pixels = image.into_rgba8().into_vec();
    let color_image = ColorImage::from_rgba_unmultiplied(size, &pixels);
    Ok(ctx.load_texture(path, color_image, Default::default()))
}
