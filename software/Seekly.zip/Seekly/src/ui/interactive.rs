use cursive::views::{Dialog, EditView, LinearLayout, SelectView, TextView};
use cursive::traits::{Nameable, Resizable};
use cursive::Cursive;
use cursive::CursiveExt;
use cursive::event::Key;
use std::path::Path;
use std::sync::{Arc, Mutex};
use std::fs;
use crate::search::finder;
use crate::search::scorer;
use crate::utils::math;
use crate::utils::file_ops;


#[derive(Clone)]
pub enum ResultType {
    File(String),       
    Directory(String),  
    Math(String),       
}


#[derive(Clone)]
pub struct DisplayResult {
    pub label: String,
    pub result_type: ResultType,
}


fn get_directory_contents(path: &Path) -> Vec<DisplayResult> {
    let mut results = Vec::new();
    if let Ok(entries) = fs::read_dir(path) {
        for entry in entries.flatten() {
            let path_str = entry.path().to_string_lossy().into_owned();
            let label = path_str.clone();
            let result_type = if entry.path().is_dir() {
                ResultType::Directory(path_str.clone())
            } else {
                ResultType::File(path_str.clone())
            };
            results.push(DisplayResult { label, result_type });
        }
    }
    results
}


fn update_results(siv: &mut Cursive, results: Vec<DisplayResult>) {
    let mut select = SelectView::<DisplayResult>::new();
    for res in results {
        select.add_item(res.label.clone(), res);
    }


    select.set_on_submit(|s, res: &DisplayResult| {
        match &res.result_type {
            ResultType::Directory(path) => {

                let contents = get_directory_contents(Path::new(path));
                update_results(s, contents);
            },
            ResultType::File(path) => {

                if let Err(e) = file_ops::open_file(Path::new(path)) {
                    s.add_layer(Dialog::info(format!("Erreur à l'ouverture du fichier: {}", e)));
                }
            },
            ResultType::Math(result) => {

                s.add_layer(Dialog::info(format!("Résultat du calcul : {}", result)));
            },
        }
    });


    let select = select.fixed_height(10).with_name("results_view");

    siv.call_on_name("results_panel", |view: &mut Dialog| {
        view.set_content(select);
    });
}


pub fn launch_ui() {
    let mut siv = Cursive::default();

    siv.add_global_callback(Key::Esc, |s| s.quit());

    let base_path = Arc::new(Mutex::new(String::from(".")));


    let base_path_clone = base_path.clone();
    let edit_view = EditView::new()
        .on_edit(move |s, query, _cursor| {
            let base = base_path_clone.lock().unwrap().clone();
            if math::is_math_expression(query) {
                match math::evaluate_expression(query) {
                    Ok(val) => {
                        let res = DisplayResult {
                            label: format!("{} = {}", query, val),
                            result_type: ResultType::Math(val.to_string()),
                        };
                        update_results(s, vec![res]);
                    },
                    Err(e) => {
                        let res = DisplayResult {
                            label: format!("Erreur d'évaluation: {}", e),
                            result_type: ResultType::Math("Erreur".into()),
                        };
                        update_results(s, vec![res]);
                    }
                }
            } 
            else
            {
                let search_results = finder::search_files(&base, query, true);
                let mut scored = scorer::score_results(&search_results, query);
                scored.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap());
                let display_results: Vec<DisplayResult> = scored.into_iter().take(10).map(|s_res| {
                    let path_str = s_res.path.to_string_lossy().into_owned();
                    let label = format!("[{:.2}] {}", s_res.score, path_str);
                    let result_type = if let Ok(metadata) = std::fs::metadata(&s_res.path) {
                        if metadata.is_dir() {
                            ResultType::Directory(path_str.clone())
                        } 
                        else 
                        {
                            ResultType::File(path_str.clone())
                        }
                    } 
                    else 
                    {
                        ResultType::File(path_str.clone())
                    };
                    DisplayResult { label, result_type }
                }).collect();
                update_results(s, display_results);
            }
        })
        .with_name("search_bar")
        .fixed_width(50);

    let select_view = SelectView::<DisplayResult>::new()
        .fixed_height(10)
        .with_name("results_view");
    let results_panel = Dialog::around(select_view)
        .title("Résultats")
        .with_name("results_panel");

    let layout = LinearLayout::vertical()
        .child(TextView::new("Tapez votre recherche (Esc pour quitter) :"))
        .child(edit_view)
        .child(results_panel);

    siv.add_fullscreen_layer(layout);
    siv.run();
}
